<?php
/**
 * Silence is golden.
 *
 * @package SWPTLS
 */
